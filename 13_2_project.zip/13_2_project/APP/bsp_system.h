#ifndef __BSPSYSTEM_H__
#define __BSPSYSTEM_H__

#include "main.h"
#include "stdio.h"
#include "string.h"
#include "stdarg.h"
#include "lcd.h"
#include "usart.h"
#include "i2c_hal.h"
#include "tim.h"
void system_init();
void schedule_init();
void schedule_run();

void led_proc();
void key_proc();
void lcd_proc();
void lcd_init();

void eeprom_write(uint8_t *eeprom_string,uint8_t addr,uint8_t num);
void eeprom_read(uint8_t *eeprom_string,uint8_t addr,uint8_t num);

typedef struct {
	uint16_t system_mode;
	uint16_t x_shop;
	float x_prise;
	uint16_t x_rep;
	uint16_t y_shop;
	float y_prise;
	uint16_t y_rep;
	uint8_t uart_buffer[64];
	uint32_t timer_5000ms;
}system_parameter;
#endif
