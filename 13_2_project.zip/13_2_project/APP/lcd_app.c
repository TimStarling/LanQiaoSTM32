#include "bsp_system.h"
extern system_parameter sp;

void lcd_init()
{
	LCD_Init();
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
}

void LCD_Sprintf(uint8_t Line,char *format,...)
{
	char String[21];
	va_list(arg);
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	LCD_DisplayStringLine(Line,String);
}

void lcd_proc()
{
	switch(sp.system_mode)
	{
		case 0:
			LCD_Sprintf(Line1,"        SHOP ");
			LCD_Sprintf(Line3,"     X:%d  ",sp.x_shop);
			LCD_Sprintf(Line4,"     Y:%d  ",sp.y_shop);
			break;
		case 1:
			LCD_Sprintf(Line1,"        PRICE");
			LCD_Sprintf(Line3,"     X:%0.1f  ",sp.x_prise);
			LCD_Sprintf(Line4,"     Y:%0.1f  ",sp.y_prise);
			break;
		case 2:
			LCD_Sprintf(Line1,"        REP  ");
			LCD_Sprintf(Line3,"     X:%d  ",sp.x_rep);
			LCD_Sprintf(Line4,"     Y:%d  ",sp.y_rep);
			break;
	}
	
}