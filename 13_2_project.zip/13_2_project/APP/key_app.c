#include "bsp_system.h"
extern system_parameter sp;
int key_up,key_val,key_down,key_old;

int key_read()
{
	int temp = 0;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0)==GPIO_PIN_RESET)temp=1;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1)==GPIO_PIN_RESET)temp=2;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2)==GPIO_PIN_RESET)temp=3;
	if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0)==GPIO_PIN_RESET)temp=4;
	return temp;
}

void key_proc()
{
	key_val = key_read();
	key_down = key_val & (key_val^key_old);
	key_up = ~key_val & (key_val^key_old);
	key_old = key_val;
	
	switch(key_down)
	{
		case 1:
			if(++sp.system_mode==3)sp.system_mode=0;
			
			break;
		case 2:
			if(sp.system_mode==0)
			{
				sp.x_shop++;
				if(sp.x_shop>sp.x_rep)sp.x_shop=0;
			}
			if(sp.system_mode==1)
			{
				sp.x_prise+=0.1;
				if(sp.x_prise > 2.05)sp.x_prise=1.0f;
				uint8_t prisex = sp.x_prise*10;
				eeprom_write(&prisex,2,1);
			}
			if(sp.system_mode==2)
			{
				sp.x_rep++;
				eeprom_write((uint8_t *)&sp.x_rep,0,1);
			}
			break;
		case 3:
			if(sp.system_mode==0)
			{
				sp.y_shop++;
				if(sp.y_shop>sp.y_rep)sp.y_shop=0;
			}
			if(sp.system_mode==1)
			{
				sp.y_prise+=0.1;
				if(sp.y_prise > 2.05)sp.y_prise=1.0f;
				uint8_t prisey = sp.y_prise*10;
				eeprom_write(&prisey,3,1);
			}
			if(sp.system_mode==2)
			{
				sp.y_rep++;
				eeprom_write((uint8_t *)&sp.y_rep,1,1);
			}

			break;
		case 4:
			if(sp.system_mode==0)
			{
				float num = (sp.x_prise*(float)sp.x_shop)+(sp.y_shop*(float)sp.y_prise);
				printf("X:%d,Y:%d,Z:%0.1f",sp.x_shop,sp.y_shop,num);
				sp.x_rep -= sp.x_shop;
				sp.y_rep -= sp.y_shop;
				if(sp.x_rep < 0)sp.x_rep=0;
				if(sp.y_rep < 0)sp.y_rep=0;
				eeprom_write((uint8_t *)&sp.x_rep,0,1);
				eeprom_write((uint8_t *)&sp.y_rep,1,1);
				sp.x_shop = 0;
				sp.y_shop = 0;
				sp.timer_5000ms = uwTick;
				__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,150);
			}
		
			break;
	}
}