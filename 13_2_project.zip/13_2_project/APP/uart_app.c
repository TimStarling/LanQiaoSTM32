#include "bsp_system.h"
extern system_parameter sp;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(sp.uart_buffer[0] == '?')printf("X:%0.1f,Y:%0.1f",sp.x_prise,sp.y_prise);
	
	HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t*)sp.uart_buffer,64);
}