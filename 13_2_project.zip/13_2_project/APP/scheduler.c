#include "bsp_system.h"
uint16_t task_num;

typedef struct{
	void (*task_func)(void);
	uint32_t rate_ms;
	uint32_t last_run;
}task_t;

static task_t schedule_task [] ={
	{led_proc,50,0},
	{key_proc,50,0},
	{lcd_proc,100,0}
};

void schedule_init()
{
	task_num = sizeof(schedule_task)/sizeof(task_t);
}

void schedule_run()
{
	uint32_t nowtime=uwTick;
	for(int i=0;i<task_num;i++)
	{
		if(nowtime > schedule_task[i].last_run + schedule_task[i].rate_ms)
		{
			schedule_task[i].last_run =nowtime;
			schedule_task[i].task_func();
		}
	}
}