#include "bsp_system.h"
uint8_t ucLed[8] = {0,0,0,0,0,0,0,0};
extern system_parameter sp;
uint32_t timer_100ms = -200;
void led_disp(uint8_t *ucLed)
{
	uint8_t temp = 0x00;
	static uint8_t temp_old = 0xff;
	for(int i=0;i<8;i++)temp |= ucLed[i]<<(7-i);
	if(temp!=temp_old)
	{
		GPIOC -> ODR &= 0x00ff;
		GPIOC -> ODR |= ~(temp<<8);
		GPIOD -> BSRR |= 0x01<<2;
		GPIOD -> BRR |= 0x01<<2;
		temp_old = temp;
	}
}

void led_proc()
{
	led_disp(ucLed);
	if(uwTick - sp.timer_5000ms < 5000)ucLed[7] = 1;
	else
	{
		__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,25);
		ucLed[7] = 0;
	}		
	if(sp.x_rep == 0 && sp.y_rep == 0)
	{
		if(uwTick - timer_100ms < 100);
		else 
		{
			ucLed[6] = !ucLed[6];
			timer_100ms = uwTick;
		}
	}
	else ucLed[6] = 0;
}