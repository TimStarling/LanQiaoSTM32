#include "led.h"

uint8_t ucled[8] = {0,0,0,0,0,0,0,0};
uint8_t led_count = 0;
void led_disp(uint8_t *ucled)
{
	uint8_t temp = 0x00;
	static uint8_t temp_old = 0xff;
	
	for(uint8_t i = 0;i < 8;i++)
		temp |= (ucled[i] << (7 - i));
	
	if(temp != temp_old)
	{
		GPIOC->ODR &= 0x00ff;
		GPIOC->ODR |= ~(temp << 8);
		GPIOD->BSRR |= 0x01 << 2;
		GPIOD->BRR |= 0x01 << 2;
		temp_old = temp;
	}
}

void led_proc(void)
{
	
	if(flag == 1&&led_count >= 4)
	{
		ucled[6] = !ucled[6];
	}else if(flag == 0) 
	{
		ucled[6] = 0;
	}
	led_count++;if(led_count > 4) led_count = 0;
	led_disp(ucled);
}




