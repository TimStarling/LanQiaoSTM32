#ifndef __SCHEDULER_H__
#define __SCHEDULER_H__

#include "bsp_system.h"

void scheduler_init(void);
void scheduler_run(void);

#endif