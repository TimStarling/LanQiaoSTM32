#include "my_lcd.h"

void my_lcd_init(void)
{
	LCD_Init();
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
}


void LcdSprintf(uint8_t Line,char * format,...)
{
	char String[21] = {0};
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	LCD_DisplayStringLine(Line,(uint8_t *)String);
}


void lcd_proc(void)
{
	if(mode == 0)
	{
		LcdSprintf(Line1,"        DATA     ");
		if(freq_mode == 0&&flag == 0)
		{
			LcdSprintf(Line3,"     M=L    ");
		}else if(freq_mode == 1&&flag == 0)
		{
			LcdSprintf(Line3,"     M=H    ");
		}        
		LcdSprintf(Line4,"     P=%d%%     ",duty);
		LcdSprintf(Line5,"     V=%.1f     ",v_temp);
	}else if(mode == 1)
	{
		LcdSprintf(Line1,"        PARA     ");
		LcdSprintf(Line3,"     R=%d     ",temp_r);
		LcdSprintf(Line4,"     K=%d     ",temp_k);
		LcdSprintf(Line5,"                  ");
	}else if(mode == 2)
	{
		LcdSprintf(Line1,"        RECD     ");
		LcdSprintf(Line3,"     N=%d     ",num_count);
		LcdSprintf(Line4,"     MH=%.1f   ",v_h_max);
		LcdSprintf(Line5,"     ML=%.1f    ",v_l_max);
		LcdSprintf(Line6,"                    ");
	}
}
