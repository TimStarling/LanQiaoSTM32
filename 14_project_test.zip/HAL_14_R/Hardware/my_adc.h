#ifndef __MY_ADC_H__
#define __MY_ADC_H__

#include "bsp_system.h"

void adc_proc(void);
void my_adc_init(void);

#endif
