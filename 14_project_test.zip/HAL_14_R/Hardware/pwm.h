#ifndef __PWM_H__
#define __PWM_H__

#include "bsp_system.h"

void pwm_set(uint16_t freq,uint8_t duty);

#endif

