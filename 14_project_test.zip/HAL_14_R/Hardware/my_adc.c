#include "my_adc.h"

uint16_t adc_buff[2][30] = {0};
float adc_val[2] = {0};
void my_adc_init(void)
{
	HAL_ADC_Start_DMA(&hadc2,(uint32_t *)&adc_buff[0][0],30);
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&adc_buff[1][0],30);
}

void adc_proc(void)
{
	uint32_t sum_r37 = 0,sum_r38 = 0;
	
	for(uint8_t i = 0;i < 30;i++)
	{
		sum_r37 += adc_buff[0][i];
		sum_r38 += adc_buff[1][i];
	}
	
	adc_val[0] = sum_r37 / 30 * 3.3f / 4096;
	adc_val[1] = sum_r38 / 30 * 3.3f / 4096;
}




