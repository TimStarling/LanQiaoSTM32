#include "ic.h"

uint16_t tim_ic_buff[30] = {0};  
uint16_t tim_ic_val = 0;

void ic_proc(void)
{
	float tim_ic_temp = 0;
	for(uint8_t i = 0;i < 30;i++)
	{
		tim_ic_temp += tim_ic_buff[i];
	}
	tim_ic_temp /= 30.0f;
	tim_ic_val = (uint16_t)(1000000.0f / (float)tim_ic_temp);
}



