#ifndef __KEY_H__
#define __KEY_H__

#include "bsp_system.h"

void key_proc(void);

#endif
