#ifndef __IC_H__
#define __IC_H__

#include "bsp_system.h"

void ic_proc(void);

#endif

