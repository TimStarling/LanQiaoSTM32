#ifndef __USER_H__
#define __USER_H__

#include "bsp_system.h"

void user_proc(void);

#endif

