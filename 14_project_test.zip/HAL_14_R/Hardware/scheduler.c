#include "scheduler.h"

uint8_t task_num = 0;

typedef struct{
	void(*task_func)(void);
	uint32_t last_run;
	uint32_t rate_ms;
}shceduler_tsak_t;

shceduler_tsak_t tasks[] = {
	{key_proc,0,20},
	{user_proc,0,50},
	{adc_proc,0,100},
	{led_proc,0,20},
	{ic_proc,0,25},
	{lcd_proc,0,60},
};


void scheduler_init(void)
{
	task_num = sizeof(tasks) / sizeof(tasks[0]);
}

void scheduler_run(void)
{
	for(uint8_t i = 0;i < task_num;i++)
	{
		if(uwTick >= (tasks[i].rate_ms + tasks[i].last_run))
		{
			tasks[i].task_func();
			tasks[i].last_run = uwTick;
		}
	}
}

