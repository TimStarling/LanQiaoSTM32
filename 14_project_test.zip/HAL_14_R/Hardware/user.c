#include "user.h"

uint8_t duty = 0;
uint8_t num_count = 0;
uint16_t freq = 3980;
uint8_t count = 0,flag = 0,freq_mode = 0,v_tim_count = 0;
float	v_num = 0,v_h_max = 0,v_l_max = 0,v_temp = 0;
                      
void user_proc(void)
{
	static uint8_t freq_mode_old = 0;
	static float v_old = 0;
	v_temp =  2.0 * 3.14f * r_num * tim_ic_val / 100 / k_num;
	
	
	if(v_tim_count >= 19)
	{
		v_tim_count = 0;
		if((v_temp - v_old) > -0.5&&(v_temp - v_old)< 0.5)
		{
			v_num = v_old;
		}
		v_old = v_temp;
	}		
	v_tim_count++;
	
	if(freq_mode == 0)
	{
		if(v_num >= v_l_max)
		{
			v_l_max = v_num;
		}
	}else if(freq_mode == 1)
	{
		if(v_num >= v_h_max)
		{
			v_h_max = v_num;
		}
	}
	
	
	
	
	if(mode == 0)
	{	
		ucled[7] = 1;
		if(control == 0)
		{
			ucled[5] = 0;
			if(adc_val[0] <= 1.0f)
			{
				duty = 10;
			}else if(adc_val[0] >= 3.0f)
			{
				duty = 85;
			}else
			{
				duty =(uint8_t)(37.5f*(adc_val[0] - 1) + 10);
			}
			pwm_set(freq,duty);
		}else if(control == 1)
		{
			ucled[5] = 1;
		}
		
		
		if(freq_mode != freq_mode_old&&count <= 97&&flag == 1)
		{
			if(freq_mode_old == 0)
			{
				freq += 40;
			}else if(freq_mode_old == 1)
			{
				freq -= 40;
			}
			pwm_set(freq,duty);
		}
		if(freq_mode != freq_mode_old&&flag == 1)
		{
			count++;
			if(count > 98)
			{
				freq_mode_old = freq_mode;
				count = 0;flag = 0;
				num_count++;
			}
		}
	}else 
	{
		ucled[7] = 0;
	}
}