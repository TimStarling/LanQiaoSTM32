#ifndef __LED_H__
#define __LED_H__

#include "bsp_system.h"

void led_proc(void);

#endif
