#ifndef __BSP_SYSTEM_H__
#define __BSP_SYSTEM_H__

#include "stdio.h"
#include "stdarg.h"
#include "string.h"

#include "main.h"
#include "tim.h"
#include "adc.h"

#include "lcd.h"

#include "key.h"
#include "ic.h"
#include "led.h"
#include "pwm.h"
#include "user.h"
#include "my_lcd.h"
#include "my_adc.h"
#include "scheduler.h"

extern uint8_t duty;
extern uint8_t num_count;
extern uint8_t count,flag,freq_mode;
extern uint16_t freq;
extern uint8_t mode,control;
extern uint8_t ucled[8];
extern uint16_t tim_ic_buff[30]; 
extern float adc_val[2];
extern float	v_num,v_temp,v_h_max,v_l_max;
extern uint16_t tim_ic_val;
extern uint8_t temp_r,temp_k,r_num,k_num,select;

#endif
