#include "key.h"

uint8_t key_val = 0,key_old = 0,key_up = 0,key_down = 0;
uint8_t mode = 0,tim_count = 0,key_long_pass  = 0,control = 0;
uint8_t temp_r = 1,temp_k = 1,r_num = 1,k_num = 1,select = 0;


uint8_t key_read(void)
{
	uint8_t temp = 0;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0) == GPIO_PIN_RESET)
	{
		temp = 1;
	}if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1) == GPIO_PIN_RESET)
	{
		temp = 2;
	}if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2) == GPIO_PIN_RESET)
	{
		temp = 3;
	}if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0) == GPIO_PIN_RESET)
	{
		temp = 4;
	}
	return temp;
}

void key_proc(void)
{
	key_val = key_read();
	key_up =  key_val & (key_val ^ key_old);
	key_down = ~key_val & (key_val ^ key_old);
	

	if(key_val == key_old && key_val != 0&&mode == 0)
	{
		tim_count++; if(tim_count >= 100) tim_count = 100;
	}else if(key_val != key_old  && tim_count >= 100)
	{
		tim_count = 0;
		key_long_pass = key_old;
	}
	
	key_old = key_val;
	
	if(key_down == 1)
	{
		mode++;
		mode %= 3;
	}
	if(key_down == 1&&mode == 2)
	{
		select = 0;
		r_num = temp_r;k_num = temp_k;
	}
	
	if(mode == 0)                          
	{
		if(key_down == 2&&flag == 0)
		{
			freq_mode = !freq_mode;
			flag = 1;
		}
		if(key_long_pass == 4)
		{
			control = 1;
			key_long_pass = 0;
		}else if(key_down == 4)
		{
			control = 0;
		}
	}
	
	if(mode == 1)
	{
		if(key_down == 2) select = !select;
		if(key_down == 3&&select == 0)
		{
			temp_r++; if(temp_r > 10) temp_r = 1;
		}else if(key_down == 3&&select == 1)
		{
			temp_k++; if(temp_k > 10) temp_k = 1;
		}else if(key_down == 4&&select == 0)
		{
			temp_r--; if(temp_r < 1) temp_r = 10;
		}else if(key_down == 4&&select == 1)
		{
			temp_k--; if(temp_k < 1) temp_k = 10;
		}		
	}
}
