#ifndef __MY_LCD_H__
#define __MY_LCD_H__

#include "bsp_system.h"

void lcd_proc(void);
void my_lcd_init(void);
void LcdSprintf(uint8_t Line,char * format,...);

#endif
