#include "pwm.h"

void pwm_set(uint16_t freq,uint8_t duty)
{
	static uint16_t freq_old = 0;
	static uint8_t duty_old = 0;
	if(freq != freq_old || duty != duty_old)
	{
		__HAL_TIM_SET_AUTORELOAD(&htim2,(uint16_t)((1000000.0f / freq) - 1));
		__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,(uint16_t)(duty / 100.0f*__HAL_TIM_GET_AUTORELOAD(&htim2)));
		
		freq_old = freq;
		duty_old = duty;
	}
	
}
