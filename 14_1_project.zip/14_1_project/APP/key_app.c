#include "key_app.h"
extern system_parameter sp;
uint8_t key_val = 0;
uint8_t key_old = 0;
uint8_t key_down = 0;
uint8_t key_up = 0;

uint8_t key_read(){
	uint8_t temp=0;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0)==GPIO_PIN_RESET)temp = 1;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1)==GPIO_PIN_RESET)temp = 2;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2)==GPIO_PIN_RESET)temp = 3;
	if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0)==GPIO_PIN_RESET)temp = 4;
	return temp;
}

void key_proc()
{
	key_val = key_read();
	key_down = key_val & (key_old ^ key_val);
	key_up = ~key_val & (key_old ^ key_val);
	key_old = key_val;
	
	 switch(key_down)//���µİ�������ж�
  {
	  case 1:
		  if(++sp.system_mode==2)sp.system_mode=0;
		  break;
	  case 2:
		  if(sp.system_mode==1){
			sp.vp1_value+=0.3;
			if(sp.vp1_value>3.3f)sp.vp1_value=0;
		  }
		  break;
	  case 3:
		  if(sp.system_mode==0)
		  {
			sp.pwm_output+=1000;
			 if(sp.pwm_output==11000)sp.pwm_output=1000;
			  pwm_set(sp.pwm_output,sp.pulse);
		  }
		  break;
	  case 4:
		  break;
  }

	
}