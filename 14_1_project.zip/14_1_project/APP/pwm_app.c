#include "pwm_app.h"
extern system_parameter sp;

void pwm_set(uint32_t pwm_output,float pulse)
{
	uint16_t arr = (1000000/(float)pwm_output);
	uint16_t persent = round(pulse * arr);
	__HAL_TIM_SET_AUTORELOAD(&htim3,arr-1);
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,persent);

}