#include "usart_app.h"
extern system_parameter sp;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(huart == &huart1)
	{
		switch(sp.uart_buffer[0]){
			case 49:
				sp.pulse = 0.1;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 50:
				sp.pulse = 0.2;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 51:
				sp.pulse = 0.3;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 52:
				sp.pulse = 0.4;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 53:
				sp.pulse = 0.5;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 54:
				sp.pulse = 0.6;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 55:
				sp.pulse = 0.7;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 56:
				sp.pulse = 0.8;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			case 57:
				sp.pulse = 0.9;
				pwm_set(sp.pwm_output,sp.pulse);
				break;
			default:
				printf("Error");
				break;
		}
		HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t*)sp.uart_buffer,50);//���ڽ���
	}
}
