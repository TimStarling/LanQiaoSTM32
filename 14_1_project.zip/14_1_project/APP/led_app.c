#include "led_app.h"
uint8_t ucLed[8] = {0,0,0,0,0,0,0,0};
uint32_t time_500ms = 0;
extern system_parameter sp;

void led_disp(uint8_t* ucLed){
	uint8_t temp = 0x00;
	static uint8_t temp_old = 0xff;
	for(int i=0;i<8;i++){
		temp|=(ucLed[i]<<(7-i));
	}
	if(temp != temp_old){
		GPIOC -> ODR &= 0x00ff;
		GPIOC -> ODR |= ~(temp<<8);
		GPIOD -> BSRR |= 0x01<<2;
		GPIOD -> BRR |= 0x01<<2;
		temp_old = temp;
	}		

}

void led_proc()
{
	led_disp(ucLed);
	if(sp.system_mode==0){
		ucLed[7] = 1;
		ucLed[6] = 0;
	}
	else if(sp.system_mode==1){
		ucLed[7] = 0;
		ucLed[6] = 1;
	}
	
	if(sp.voltage_value>sp.vp1_value){
		if(uwTick - time_500ms >= 100){
			ucLed[5] = !ucLed[5];
			time_500ms = uwTick;
		}
	}
	else ucLed[5] = 0;
	
}
