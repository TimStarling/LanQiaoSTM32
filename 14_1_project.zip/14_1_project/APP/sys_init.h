#ifndef __SYSINIT_H__
#define __SYSINIT_H__

#include "bsp_system.h"

void system_init();

#endif
