#include "adc_app.h"
extern system_parameter sp;
void adc_proc(){
	uint32_t value_temp=0;
	for(int i=0;i<30;i++){
		value_temp = sp.adc_value[i] + value_temp;
	}
	sp.voltage_value = (value_temp / 30.0f) * (3.3f / 4095);

}