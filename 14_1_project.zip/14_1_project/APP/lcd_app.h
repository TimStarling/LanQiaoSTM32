#ifndef __LCDAPP_H__
#define __LCDAPP_H__

#include "bsp_system.h"
void Lcd_init();
void Lcd_proc();
#endif
