#include "lcd_app.h"
extern system_parameter sp;
void LcdSprintf(uint8_t Line, char *format,...){
	char String[21];
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	LCD_DisplayStringLine(Line,String);
}

void Lcd_init(){
	LCD_Init();
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
}

void Lcd_proc()
{
	switch(sp.system_mode)
	{
		case 0:
			LcdSprintf(Line3,"        DATA");
			LcdSprintf(Line4,"     VR37:%0.2fV  ",sp.voltage_value);
			LcdSprintf(Line5,"     PA7:%dHz  ",sp.pwm_output);
			break;
		case 1:
			LcdSprintf(Line3,"        PARA");
			LcdSprintf(Line4,"     VP1:%0.1fV      ",sp.vp1_value);
			LcdSprintf(Line5,"                 ");
			break;
	
	}

}