#ifndef __ADCAPP_H__
#define __ADCAPP_H__

#include "bsp_system.h"
void adc_proc();
#endif
