#ifndef __BSPSYSTEM_H__
#define __BSPSYSTEM_H__

#include "main.h"
#include "stdarg.h"
#include "string.h"
#include "math.h"
#include "lcd.h"
#include "lcd_app.h"
#include "tim.h"
#include "usart.h"
void system_init();
void schedule_init();
void schedule_run();

void led_proc();
void key_proc();
void Lcd_init();
void Lcd_proc();

typedef struct{
	uint16_t system_mode;
	uint32_t adc_value[30];
	float voltage_value;
	float vp1_value;
	uint32_t pwm_output;
	float pulse;
	uint8_t uart_buffer[50];
}system_parameter;

void adc_proc();
void pwm_set(uint32_t pwm_output,float pulse);

#endif
