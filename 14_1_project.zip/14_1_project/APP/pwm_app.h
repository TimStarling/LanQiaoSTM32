#ifndef __PWMAPP_H__
#define __PWMAPP_H__

#include "bsp_system.h"
void pwm_set(uint32_t pwm_output,float pulse);
#endif
