#ifndef __TIM_APP_H__
#define __TIM_APP_H__

#include "bsp_system.h"

void ic_proc(void);

#endif
