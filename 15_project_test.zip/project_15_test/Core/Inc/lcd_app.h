#ifndef __LCD_APP_H__
#define __LCD_APP_H__

#include "bsp_system.h"

void lcd_proc(void);

#endif


