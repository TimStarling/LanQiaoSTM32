#ifndef __TIMAPP_H__
#define __TIMAPP_H__

#include "bsp_system.h"

void tim_ic_proc();
#endif
