#ifndef __LEDAPP_H__
#define __LEDAPP_H__

#include "bsp_system.h"

void led_proc();

#endif
