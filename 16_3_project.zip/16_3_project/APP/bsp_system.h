#ifndef __BSPSYSTEM_H__
#define __BSPSYSTEM_H__

#include "main.h"
#include "stdio.h"
#include "string.h"
#include "stdarg.h"
#include "lcd.h"
#include "lcd_app.h"

void system_init();
void scheduler_init();
void scheduler_run();

typedef struct{
	uint16_t system_mode;//ϵͳģʽ 0-2
	uint32_t tim_input[30];
	uint32_t tim_value;
	uint16_t cardiac_frq;//����Ƶ��
	uint16_t cardiac_frq_max;
	uint16_t cardiac_frq_min;
	uint32_t adc_input[30];
	float adc_value;
	uint16_t high_alert[2];//0-����ǰ 1-�����
	uint16_t low_alert[2];
	uint16_t change_mode;//0-�˳� 1-����
	uint16_t alert_num;//0-���� 1-����
	uint16_t warning_cnt;
	uint16_t warning_bit;
	uint16_t count_5s;
	
}system_parameter;

void led_proc();
void key_proc(void);
void lcd_init();
void lcd_proc();

void tim_ic_proc();
void adc_proc();
void overfall_test();
#endif
