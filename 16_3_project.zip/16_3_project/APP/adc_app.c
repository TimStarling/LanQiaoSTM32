#include "adc_app.h"
extern system_parameter sp;
extern uint8_t ucLed[8];
void adc_proc(){
	int temp_adc=0;
	int alert_value=0;
	for(int i=0;i<30;i++){
		temp_adc += sp.adc_input[i];
	}
	
	sp.adc_value = ((float)temp_adc/30)*(3.3f/4095);
	if(sp.adc_value>=3)alert_value=150;
	else if(sp.adc_value<=1)alert_value=60;
	else alert_value = (sp.adc_value * 45) + 15;
	if((sp.alert_num==0)&&(sp.system_mode==2)&&(sp.change_mode==1))sp.high_alert[0] = alert_value;
	if((sp.alert_num==1)&&(sp.system_mode==2)&&(sp.change_mode==1))sp.low_alert[0] = alert_value;

}

void overfall_test()
{
	if((sp.cardiac_frq>sp.high_alert[1])&&(sp.warning_bit==0)){//���޳�
		sp.warning_cnt++;
		sp.warning_bit=1;
		ucLed[2]=1;
		sp.count_5s = uwTick;
	}
	if((sp.cardiac_frq<sp.low_alert[1])&&(sp.warning_bit==0)){//���޳�
		sp.warning_cnt++;
		sp.warning_bit=1;
		ucLed[2]=1;
		sp.count_5s = uwTick;
	}
	if((sp.cardiac_frq<=sp.high_alert[1])&&(sp.cardiac_frq>=sp.low_alert[1]))sp.warning_bit=0;
}