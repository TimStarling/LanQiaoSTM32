#include "lcd_app.h"
extern system_parameter sp;

void LcdSprintf(uint8_t Line,char*format,...){
	char String[21];
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	LCD_DisplayStringLine(Line,String);
	
}

void lcd_init()
{
	LCD_Init();
	LCD_Clear(Black);
	LCD_SetTextColor(White);
	LCD_SetBackColor(Black);

}

void lcd_proc(void)
{
	switch(sp.system_mode){
		case 0:
			LcdSprintf(Line0,"    ");
			LcdSprintf(Line1,"       HEART   ");
			LcdSprintf(Line2,"    ");
			LcdSprintf(Line3,"      Rate:%d    ",sp.cardiac_frq);
			LcdSprintf(Line4,"       Con:%d      ",sp.warning_cnt);
			LcdSprintf(Line5,"    ");
		  break;
		case 1:
			LcdSprintf(Line0,"    ");
			LcdSprintf(Line1,"       RECORD  ");
			LcdSprintf(Line2,"    ");
			LcdSprintf(Line3,"       Max:%d  ",sp.cardiac_frq_max);
			LcdSprintf(Line4,"       Min:%d  ",sp.cardiac_frq_min);
			LcdSprintf(Line5,"    ");
		  break;
	    case 2:		
			LcdSprintf(Line0,"    ");
			LcdSprintf(Line1,"        PARA  ");
			LcdSprintf(Line2,"    ");
			LcdSprintf(Line3,"      High:%d   ",sp.change_mode?sp.high_alert[0]:sp.high_alert[1]);
			LcdSprintf(Line4,"       Low:%d   ",sp.change_mode?sp.low_alert[0]:sp.low_alert[1]);
			LcdSprintf(Line5,"    ");			
		  break;
	
	}
}
