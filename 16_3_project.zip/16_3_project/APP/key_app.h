#ifndef __KEYAPP_H__
#define __KEYAPP_H__

#include "bsp_system.h"
void key_proc(void);
#endif
