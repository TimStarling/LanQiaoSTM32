#include "tim_app.h"
extern system_parameter sp;

void tim_ic_proc()
{
	int temp_value =0 ;
	for(int i=0;i<30;i++){
		temp_value+=sp.tim_input[i];
	}
	temp_value = (float)temp_value/30.0f;
	sp.tim_value = (int)((float)(1000.0f * 1000.0f) / (float)temp_value);
	
	if(sp.tim_value>=2000)sp.cardiac_frq=200;
	else if(sp.tim_value<=1000)sp.cardiac_frq=30;
	else sp.cardiac_frq = 0.17f*sp.tim_value - 140;
}