#include "bsp_system.h"

uint8_t task_num;
typedef struct {
	
	void (*task_func)(void);
	uint32_t rate_ms;
	uint32_t last_run;
		
}task_t;

static task_t scheduler_task[]={
	{led_proc,50,0},
	{key_proc,100,0},
	{lcd_proc,100,0},
	{tim_ic_proc,100,0},
	{adc_proc,100,0},
	{overfall_test,100,0}
};

void scheduler_init()
{
	task_num = sizeof(scheduler_task)/sizeof(task_t);
}

void scheduler_run(){
	for (uint8_t i=0;i<task_num;i++){
		uint32_t now_time = uwTick;
		if(now_time>=scheduler_task[i].rate_ms+scheduler_task[i].last_run){
			scheduler_task[i].last_run=uwTick;
			scheduler_task[i].task_func();
		}
		
	}

}