#ifndef __KEYAPP_H
#define __KEYAPP_H

#include "bsp_system.h"
void key_proc(void);


#endif