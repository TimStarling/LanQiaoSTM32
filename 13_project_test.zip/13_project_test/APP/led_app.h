#ifndef _LEDAPP_H__
#define _LEDAPP_H__
#include "bsp_system.h"

void led_proc();

#endif