#ifndef __LCDAPP_H__
#define __LCDAPP_H__

#include "bsp_system.h"
void lcd_proc(void);
void lcd_init();
#endif
