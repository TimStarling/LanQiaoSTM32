#ifndef __UARTAPP_H__
#define __UARTAPP_H__

#include "bsp_system.h"

#endif
