#include "adc_app.h"
extern system_parameter sp;

void adc_proc()
{
	uint32_t temp_num[2] = 0;
	for(int i= 0;i<30;i++){
		temp_num[0] += sp.adc_value[0][i];
		temp_num[1] += sp.adc_value[1][i];
	}
	
	sp.voltage_value[0] = ((float)temp_num[0]/30)*(3.3f/4095);
	sp.voltage_value[1] = ((float)temp_num[1]/30)*(3.3f/4095);
}