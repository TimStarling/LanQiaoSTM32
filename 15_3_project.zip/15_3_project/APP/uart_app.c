#include "uart_app.h"
extern system_parameter sp;
uint8_t temp1[3] = "R37";
uint8_t temp2[3] = "R38";
	
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	
	if(huart == &huart1)
	{
		if(sp.uart_buffer[2]=='7')printf("R37:%d,%d,%0.1f%%",sp.test_num[0],sp.pass_num[0],sp.pass_proportion[0]*100);
		if(sp.uart_buffer[2]=='8')printf("R38:%d,%d,%0.1f%%",sp.test_num[1],sp.pass_num[1],sp.pass_proportion[1]*100);
		HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t*)sp.uart_buffer,50);//���ڽ���
	}
}