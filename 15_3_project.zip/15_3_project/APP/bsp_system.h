#ifndef __BSPSYSTEM_H__
#define __BSPSYSTEM_H__

#include "main.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "lcd_app.h"
#include "uart_app.h"
#include "lcd.h"
#include "usart.h"

typedef struct{
	uint16_t system_mode;
	uint32_t adc_value[2][30];
	float voltage_value[2];
	int B2_choose;
	float goods_standard[4];
	int pass_num[2];//ͨ������
	int test_num[2];//�������
	float pass_proportion[2];
	uint8_t uart_buffer[50];
	uint8_t led_flash_bit[2];
}system_parameter;

void system_init();

void schedule_init(void);
void schedule_run(void);

void led_proc();
void key_proc(void);
void lcd_proc(void);
void lcd_init();

void adc_proc();
#endif
